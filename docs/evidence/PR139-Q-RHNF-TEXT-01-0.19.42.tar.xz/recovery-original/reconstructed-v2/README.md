# V1-EVR-01 RECONSTRUCTED — frozen author-side verification

This new suite replaces only the unavailable external artifact identity requirement. It is implementation-author evidence. It is neither the lost original suite nor independent Q/V1 acceptance. Published authorities are preserved in ../authority. The owner-authorized later independent reviewer must challenge these hosts, check this mapping and replay both historical sources.

## Assertion mapping and factual differences

| Published original assertion | Reconstructed assertion and raw witness |
| --- | --- |
| V1-RH-01 canonical: real Arm → Capture current page with zero supported prices preserves raw pricePageItems, nested condition, original successful clock/URLs and nonfinancial stores; historical be9086e deletes condition/adds normalizedName | RH-01 canonical; exact historical row comparison excluding only permitted attempt fields; before/after full stores, writes, UI and arm in RH-canonical.json |
| V1-RH-01 aliases: preserve id/name/price/qty/text/condition, original representation/order and unknown extensions | RH-01 legacy; two ordered alias rows plus pricingItems representation and wrapper metadata; RH-legacy.json |
| V1-NF-01 JSON literal unitPrice:1e400: no serialized null quote or success/count/completion/arm loss | NF-01 numeric overflow; original literal input in inputs.json; NF-overflow.json |
| V1-NF-01 explicit unitPrice:"Infinity": same zero-write whole-receipt rejection | NF-01 explicit Infinity string; NF-infinity.json |
| Independent Q $Infinity/$NaN/$1e400 at quantity zero beside Fixture Item x2 @ $1234 = $2468 | Three exact published text inputs; initialized receipt UI click, original quote500/count7/time retained, zero writes/proof/arm loss; Q-*.json |
| Original finite-positive and genuinely missing-unit total/quantity controls | finite and missing-unit-fallback controls; quote1234/count8/one marker, matching arm consumed and repeat click exactly once |

The two original fixture files and their host/raw/TAP dependencies are permanently unavailable. We do not claim byte identity or source equivalence. This suite contains newly authored assertions. The maintained production DOM/storage host files are copied byte-for-byte from starting 7ffadc0; the lost originals' complete host details cannot be compared. Per-persistent-store namespacing keeps real native Node locks independent across fixtures. Node VM DOM, deterministic clock, synthetic storage, timer scheduler, confirmation and navigation recording are host facilities, not real browser/account evidence. Strong-arm creation uses native Web Crypto. Production initialization, delegated click handlers, receipt parsing, captureTransition, authoritative reread, real writer/readback/cleanup all execute from the selected entire immutable script. No parser/writer replacement exists.

For the direct route we supply ordinary body.cloneNode behavior absent from the shared host, as explicitly documented in the original V1 report. The direct case starts from the fixture's genuine persisted arm and performs Capture current page. Historical canonical data adds a nested unknown extension; the legacy case adds a second ordered row, pricingItems and unknown wrapper metadata to strengthen representation checks. These additional witnesses are new synthetic data, not recovered originals. The original all-zero direct check counter still moves 7→8; only specified attempt/check fields are excluded from exact raw-row comparison. All other fields and key presence must match. Receipt cases allow only the separately frozen R8 counterparty link/profile and Ledger timestamp delta, verified by the host's complete expected-Ledger string.

The historical be9086e execution includes the three Q text cases as extra sensitivity diagnostics: they are also vulnerable there. The exact starting 7ffadc0 must pass the original four reconstructed assertions and controls and fail precisely the three Q cases. No assertion may be modified after freeze. Raw snapshots are written before acceptance assertions, so failed executions retain all state. Current versus historical test output directories must be separate.

## Commands and dependencies

Run from any directory after extracting this archive. No npm package is needed for these tests; only Node 24.19.0 built-in node:test, assert/strict, fs, path, vm, crypto; native navigator.locks and Web Crypto are required. Exact Node executable SHA-256 and process.versions are in runtime.json. acorn 8.15.0 is used only for the separate source audit, with its source/lockfile included in ../dependencies.

```
TSIMM_TEST_SCRIPT=<archive>/sources/be9086e.user.js EVR_OUTPUT=<output>/be9086e node --test-reporter=tap --test-timeout=15000 <archive>/reconstructed-v2/witnesses.test.cjs
TSIMM_TEST_SCRIPT=<archive>/sources/7ffadc0.user.js EVR_OUTPUT=<output>/7ffadc0 node --test-reporter=tap --test-timeout=15000 <archive>/reconstructed-v2/witnesses.test.cjs
TSIMM_TEST_SCRIPT=<checkout>/TornScripture-Item-Market-Margin.user.js EVR_OUTPUT=<output>/fixed node --test-reporter=tap --test-timeout=15000 <archive>/reconstructed-v2/witnesses.test.cjs
```

MANIFEST.sha256 freezes all test/input/host/documentation/runtime files before product edits. The companion frozen tar.gz and its external SHA-256 preserve the immutable fixture bundle. Historical source files have their separate SHA-256 manifest. Raw before/after witnesses and full TAP execution receipts are preserved separately from the frozen bundle. Later green must use the same bundle. Archive instructions will permit independent retrieval and checksum replay through the existing PR branch without assuming a workspace path.

Known limits: no claim of real desktop/TornPDA, layout, process-kill/BFCache, userscript-manager timing, external provider carrier or real-account Ledger Integrity. A successful author replay leaves independent fixture fidelity/product Q, full V1 and owner V2/merge gates open.

## Pre-edit fixture correction, v2

The first frozen bundle and its complete failing logs remain unchanged in reconstructed/ and red-*/. Its RH neighbor assertion selected array index 1, which was the armed trader after normal UI sorting. The captured raw witnesses proved only that mistaken assertion failed on 7ffadc0; original historical raw-item preservation assertions passed. V2 changes exactly that one selector to compare trader id b before/after. No invariant is removed or relaxed. It resolves a reconstruction defect before product edits, rather than changing product code to satisfy the host. The fixture-source diff is preserved separately. Both historical sources must now replay with this new immutable bundle.
