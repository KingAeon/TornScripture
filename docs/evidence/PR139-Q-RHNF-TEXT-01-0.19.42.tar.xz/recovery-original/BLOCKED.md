# BLOCKED — Q-RHNF-TEXT-01 under V1-EVR-01

The attempted receipt admission correction introduces a supported-format regression. `2 x Fixture Item @ $1,234 = $2,468` succeeds on exact required starting 7ffadc0 but is rejected by the uncommitted candidate. This is the single decisive blocker. The owner's explicit STOP rule for failed post-edit tests was applied; no further product/test edits, commit, push, independent Q/V1/V2, release or account action followed discovery.

## Executed workspace proof

- Complete, clean, nonshallow native clone was established at /workspace/TornScripture before edits. Shell, Git 2.52.0, Node 24.19.0, native Web Locks and Web Crypto executed. Network-enabled sandbox access established clone and a successful non-force existing-branch push dry run; the initial default-sandbox proxy failure was overcome without provisioning.
- Exact branch agent/bl-r01b-v22-trader-refresh-implementation; starting HEAD 7ffadc0f0a41543e4d6cf2b3b613ea7721271041; tree c76450e1a723b74d617fbda74633ce3ccf038c68; sole parent 7f40d9e70b9e53682308e1487d044758dda19303. All historical pins exist. Released main/PR base 529400117f727da31a058b7941c29693f40bb1b3. All 223 actual checkout blobs match the nontruncated GitHub tree. PR open/draft/unmerged and auto-merge null at live preflight.
- `git fsck --full` succeeded. Baseline `node --test --test-reporter=tap --test-timeout=15000 tests/*.test.js` exited 0, 20/20 files, 26.307 seconds, no failures/cancellations/skips/todo. All 20 files also executed individually: 1920 node:test cases + inventory assertion script = 1921 maintained cases. All 34 tracked JS/CJS baseline syntax checks passed.

## Frozen reconstructed evidence

The original lost V1 external files were not recovered and are not claimed executed. A new plainly labeled external suite copies the current maintained real-production UI hosts, selects entire exact source bytes via TSIMM_TEST_SCRIPT, invokes genuine arm/capture/receipt clicks and native transitions, and preserves full raw books, input, arm, Ledger, seven neighboring stores, writes and feedback. No product parser/writer substitutes.

The first frozen version had a reconstruction error: its RH neighbor assertion used array index 1, which sorting made the armed trader. Both immutable first-version source and failing logs remain preserved. A separately versioned pre-product-edit v2 corrects exactly the neighbor selector to stable id b, with the full diff and explanation retained. All original raw-history/financial/arm invariants remain. This was resolved before product edits; no failed frozen artifact was silently overwritten.

Final frozen fixture bundle SHA-256: cfc61dd8702559a140d63aabc8ae246997c83139648ab7e484f82dfea0f36e41. See reconstructed-v2/README.md, MANIFEST.sha256, runtime.json, inputs.json and sources/MANIFEST.sha256. Native randomness supplies new strong IDs each run; exact arm values are preserved within raw before/after evidence, not expected byte-identical between executions.

Historical replay, original 15000ms timeout, complete execution receipts:

| Selected exact source | Frozen v2 suite |
| --- | --- |
| be9086e | 2 PASS / 7 expected FAIL: four original RH/NF failures plus three Q mixed-text failures; both healthy controls pass |
| 7ffadc0 | 6 PASS / 3 expected FAIL: four reconstructed historical assertions and controls pass; exactly the three Q failures remain |

The historical raw witnesses confirm canonical/legacy field deletion, numeric overflow/string Infinity serialized as null, false marker parsedCount1, count7→8, new capture clock, consumed arm and success feedback. Exact Q inputs on 7ffadc0 confirm quote500→1234 and the same false success fields. This is author-side reconstruction, not independent fixture equivalence approval.

## Uncommitted attempt and decisive failure

Only prepareTraderCapturePriceItems and priceItemsFromParsedReceipt change in production, plus the five coherent draft 0.19.41→0.19.42 sentinels. The boundary inspects raw candidate-row quantities and complete currency tokens, and also examines text with no surviving parsed item. The existing financial parsers, captureTransition and writeCaptureTraders are unchanged. Matching version test updates to explicit 0.19.42. A new maintained 110-case text matrix is present, untracked; no original maintained assertion was weakened.

The new matrix on original source: 61 PASS / 49 expected rejection failures. First post-edit run: 107 PASS / 3 FAIL, no skipped/cancelled/todo, 13.145 seconds. Two failures come from newly authored negative controls containing a single finite total 1e308: the existing allowed total/quantity fallback produces finite 5e307, so those expectations need explicit documented review. They remain unchanged in both pre-edit and attempted sources/logs.

The real regression is the existing supported quantity-first finite row above. The new raw suffix matcher mistakes the leading `2 x` form for a name-first row, extracting `Fixture` as the quantity before consulting the valid prefix quantity. Separate production UI diagnostic and full raw snapshots confirm:

| State | Original 7ffadc0 | Uncommitted candidate |
| --- | --- | --- |
| Exit for supported-format assertion | 0 | 1 |
| Quote | 1234 | 500 |
| Count | 8 | 7 |
| Completion marker | 1 | 0 |
| Book writes | 1 | 0 |
| Arm | consumed after success | retained |
| Feedback | 1 prices captured | Not captured: invalid price |

No unsafe account data was touched; these are synthetic full production-runtime storage witnesses. No green completion, author acceptance or live-device claim is made.

Stopped candidate IMM SHA-256: c7d3d5d16b5a6373e091ac749a1ba64336ac9f21748e815a8d4194a1fe3709b2. Its exact full source is sources/blocked-candidate.user.js. Tracked diff is blocked-correction.patch; untracked test is blocked-text-admission.test.js. HEAD/tree/parent remain the original pinned values. The working tree intentionally retains the failed uncommitted attempt for review; there is no published correction commit.

Read-only post-stop AST audit verifies all 21 protected complete declarations/bodies match the eight required historical controls and expected published hashes. Exactly two existing declarations changed, none added/removed; whole-source reconstruction permits only those two and five version markers. Storage-key literals, metadata permissions/public update URLs, safety boundary, native lock, shared writer and its four callers, 35 listener/35 timeout/1 interval/5 observer/6 fetch sites are unchanged. Report bytes remain unchanged, SHA-256 8f9884aad859476a16ae3106a3b5551de51938ede4e13c193b2be4d40923dd4b. Candidate IMM syntax and git diff --check passed. These checks do not override the failing behavioral acceptance.

## Exact remaining work

Repair the supported prefix-row classification within frozen scope and resolve the two finite fallback test expectations transparently, preserving all failed source/logs. Then execute the unchanged frozen suite green, full expanded acceptance, all maintained/focused suites, all current tracked JS/CJS syntax, full diff/caller/effect/storage/version/protected/secret audits and Git integrity. Complete owner backup/rollback/manual instructions and implementation documentation. Publish an independently retrievable evidence archive and verify retrieval/checksums. Only complete author acceptance can authorize committing and non-force pushing the bounded correction to existing PR139; then verify remote commit/tree/parent/all blobs and post one consolidated report linked to Issue142.

The present BLOCKED archive is a local preservation artifact, not a durable independently hosted evidence publication. Durable publication remains incomplete. No remote branch, PR readiness, Issue142 state or released main was changed. Independent fixture-fidelity/product Q, full V1 and owner desktop/TornPDA V2/Ledger Integrity and merge/release remain separate gates.

Do not install this failed candidate. Preserve current raw user backups/authority if later performing owner-authorized manual work. No migrations were introduced. Do not restore stale backups or reinstall a known-defective historical build automatically. A future forward correction/revert must preserve existing proof and remain subject to author acceptance and the existing owner gates.
