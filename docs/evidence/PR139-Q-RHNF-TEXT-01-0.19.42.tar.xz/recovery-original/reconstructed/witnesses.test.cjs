// V1-EVR-01 RECONSTRUCTED. These are new assertions, never recovered originals.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
assert.ok(process.env.TSIMM_TEST_SCRIPT, 'select exact production source explicitly');
assert.ok(process.env.EVR_OUTPUT, 'keep each execution in a distinct evidence directory');
const { fixture, feedback, bookWrites, K, PENDING, turn } = require('./hosts/imm-receipt-harness.cjs');
const { Element } = require('./hosts/imm-capture-harness.cjs');
const data = require('./inputs.json');
const clone = value => JSON.parse(JSON.stringify(value));
const rows = bytes => { const r = JSON.parse(bytes); return Array.isArray(r) ? r : r.traders; };
const snapshot = p => ({ storage: Object.fromEntries(p.memory), session: Object.fromEntries(p.session),
  input: p.input.value, draft: clone(p.state.receiptAuditDraft), feedback: feedback(p),
  writes: clone(p.writes), navigations: clone(p.navigations) });
const persist = (name, value) => {
  fs.mkdirSync(process.env.EVR_OUTPUT, { recursive: true });
  fs.writeFileSync(path.join(process.env.EVR_OUTPUT, name + '.json'), JSON.stringify(value, null, 2) + '\n');
};
function checkAll(checks) {
  const failures = [];
  for (const [label, run] of checks) try { run(); } catch (e) { failures.push(label + ': ' + e.message); }
  assert.deepEqual(failures, [], 'all frozen state invariants');
}
for (const kind of ['canonical', 'legacy']) test('V1-EVR-01 RECONSTRUCTED RH-01 ' + kind, async () => {
  const p = await fixture({ twoTraders: true });
  const traders = rows(p.memory.get(K.book));
  const a = traders.find(row => row.id === 'a');
  a.pricePageItems = kind === 'canonical' ? [clone(data.canonical)]
    : [clone(data.legacy), { ...clone(data.legacy), id: 2, name: 'Other Item', price: '600' }];
  if (kind === 'legacy') a.pricingItems = [clone(data.legacy)];
  a.unknownHistorical = { ordered: [false, null, { x: 'retained' }] };
  p.memory.set(K.book, JSON.stringify({ schemaVersion: 3, opaque: { keep: [2, 1] }, traders }));
  p.document.body.cloneNode = () => new Element('A page with no supported prices');
  const before = snapshot(p);
  await p.clickAction('trader-capture-current-page'); await turn(); await p.drain();
  const after = snapshot(p); persist('RH-' + kind, { before, after });
  const next = rows(after.storage[K.book]).find(row => row.id === 'a');
  const historical = row => { const c = clone(row); for (const key of ['pricePageLastCheckedAt', 'pricePageCaptureCount',
    'pricePageLastOutcome', 'pricePageLastReason', 'pricePageLastResult', 'updatedAt']) delete c[key]; return c; };
  checkAll([
    ['raw item representation, order, unknown fields and successful history', () => assert.deepEqual(historical(next), historical(a))],
    ['neighbor and wrapper', () => { assert.deepEqual(rows(after.storage[K.book])[1], traders[1]); assert.deepEqual(JSON.parse(after.storage[K.book]).opaque, { keep: [2, 1] }); }],
    ['frozen check count is not success', () => { assert.equal(next.pricePageCaptureCount, 8); assert.equal(next.pricePageLastOutcome, 'loading_or_inconclusive'); }],
    ['arm retained', () => assert.equal(after.storage[PENDING], before.storage[PENDING])],
    ['financial and neighbor bytes', () => { assert.equal(after.storage[K.ledger], before.storage[K.ledger]); for (const [key, value] of p.protectedBytes) assert.equal(after.storage[key], value); }],
    ['truthful non-success', () => { assert.match(feedback(p).at(-1), /previous snapshot was kept/); assert.doesNotMatch(feedback(p).at(-1), /\d+ prices captured/); }],
  ]);
});
async function rejected(name, input) {
  const p = await fixture({ twoTraders: true }); p.input.value = input;
  const before = snapshot(p); await p.link(); await p.drain(); const after = snapshot(p);
  persist(name, { before, after });
  const next = rows(after.storage[K.book]).find(row => row.id === 'a');
  checkAll([
    ['zero book writes and raw snapshot', () => { assert.equal(after.storage[K.book], before.storage[K.book]); assert.equal(bookWrites(p).length, 0); }],
    ['original quote/count/success clock', () => { assert.equal(next.pricePageItems[0].unitPrice, 500); assert.equal(next.pricePageCaptureCount, 7); assert.equal(next.pricePageCapturedAt, '2026-10-01T12:00:00.000Z'); }],
    ['no completion or success outcome', () => { assert.equal(next.receiptLinkCompletions?.length || 0, 0); assert.notEqual(next.pricePageLastOutcome, 'captured'); }],
    ['strong arm retained exactly', () => assert.equal(after.storage[PENDING], before.storage[PENDING])],
    ['input retained in production UI', () => { assert.equal(p.input.value, input); p.assertInput(input); }],
    ['truthful rejection feedback', () => { assert.match(feedback(p).at(-1), /not captured: invalid price/i); assert.doesNotMatch(feedback(p).at(-1), /\d+ prices captured/); }],
    ['R8 only financial exception and seven adjacent stores', () => p.assertAccounting()],
  ]);
}
test('V1-EVR-01 RECONSTRUCTED NF-01 numeric overflow', () => rejected('NF-overflow', data.overflow));
test('V1-EVR-01 RECONSTRUCTED NF-01 explicit Infinity string', () => rejected('NF-infinity', data.infinity));
for (const token of data.qTokens) test('Q-RHNF-TEXT-01 unchanged behavioral witness $' + token,
  () => rejected('Q-' + token, data.validRow + '\nOther Item x0 @ $' + token));
for (const mode of ['finite', 'missing-unit-fallback']) test('V1-EVR-01 positive sensitivity control ' + mode, async () => {
  const p = await fixture({ twoTraders: true });
  p.input.value = JSON.stringify({ items: [{ itemId: 1, itemName: 'Fixture Item', quantity: 2,
    ...(mode === 'finite' ? { unitPrice: 1234 } : {}), totalValue: 2468 }] });
  const before = snapshot(p); await p.link(); await p.drain(); const after = snapshot(p);
  await p.link(); await p.drain(); persist('control-' + mode, { before, after, afterRepeat: snapshot(p) });
  const a = rows(after.storage[K.book]).find(row => row.id === 'a');
  assert.equal(a.pricePageItems[0].unitPrice, 1234); assert.equal(a.pricePageCaptureCount, 8);
  assert.equal(a.receiptLinkCompletions.length, 1); assert.equal(a.receiptLinkCompletions[0].parsedCount, 1);
  assert.equal(p.memory.has(PENDING), false); assert.equal(bookWrites(p).length, 1); p.assertAccounting();
  assert.match(after.feedback.at(-1), /1 prices captured/);
});
