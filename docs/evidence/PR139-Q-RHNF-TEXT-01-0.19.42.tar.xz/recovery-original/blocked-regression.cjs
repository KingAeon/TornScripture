// Diagnostic only: preserve the newly introduced supported-format regression.
const fs = require('node:fs');
const assert = require('node:assert/strict');
const { fixture, feedback, bookWrites, K, PENDING } = require('./reconstructed-v2/hosts/imm-receipt-harness.cjs');
(async () => {
  const p = await fixture({ twoTraders: true });
  const input = '2 x Fixture Item @ $1,234 = $2,468'; p.input.value = input;
  const take = () => ({ storage: Object.fromEntries(p.memory), input: p.input.value,
    draft: p.state.receiptAuditDraft, feedback: feedback(p), writes: p.writes.slice() });
  const before = JSON.parse(JSON.stringify(take())); await p.link(); await p.drain();
  const after = take(), row = JSON.parse(p.memory.get(K.book)).find(t => t.id === 'a');
  fs.writeFileSync(process.env.EVR_OUTPUT, JSON.stringify({ source: process.env.TSIMM_TEST_SCRIPT,
    before, after, summary: { quote: row.pricePageItems[0].unitPrice, captureCount: row.pricePageCaptureCount,
      completionCount: row.receiptLinkCompletions.length, armRetained: p.memory.get(PENDING) === before.storage[PENDING],
      bookWrites: bookWrites(p).length, feedback: feedback(p).at(-1) } }, null, 2) + '\n');
  assert.equal(row.pricePageItems[0].unitPrice, 1234, 'supported quantity-first finite receipt must capture');
  assert.equal(row.pricePageCaptureCount, 8); assert.equal(row.receiptLinkCompletions.length, 1);
  assert.equal(bookWrites(p).length, 1); assert.equal(p.memory.has(PENDING), false); p.assertAccounting();
})().catch(e => { console.error(e); process.exitCode = 1; });
