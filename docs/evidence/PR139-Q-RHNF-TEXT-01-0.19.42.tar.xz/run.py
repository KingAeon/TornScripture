import subprocess, os, json, pathlib, time, sys, re
ROOT=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path(os.environ.get('EVR_REPO',str(ROOT/'source' if (ROOT/'source').exists() else pathlib.Path('/workspace/TornScripture'))))
def run(name,args,env=None):
    out=ROOT/'runs'/name;out.mkdir(parents=True,exist_ok=True)
    start=time.monotonic()
    with (out/'stdout.tap').open('w') as stdout,(out/'stderr.txt').open('w') as stderr:
        p=subprocess.run(args,cwd=REPO,env={**os.environ,**(env or {})},stdout=stdout,stderr=stderr,timeout=180)
    body=(out/'stdout.tap').read_text()
    totals={k:int(v) for k,v in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)$',body,re.M)}
    receipt={'command':args,'environment':env or {},'exit':p.returncode,'seconds':time.monotonic()-start,'totals':totals}
    (out/'command.json').write_text(json.dumps(receipt,indent=2)+'\n');print(name,json.dumps(receipt),flush=True)
    return receipt
if __name__=='__main__':
    mode=sys.argv[1]
    old=ROOT/'recovery-original'
    if mode=='red':
        for ref in ['be9086e','7ffadc0']:
            r=run('red-'+ref,['node','--test-reporter=tap','--test-timeout=15000',str(old/'reconstructed-v2/witnesses.test.cjs')],{'TSIMM_TEST_SCRIPT':str(old/'sources'/f'{ref}.user.js'),'EVR_OUTPUT':str(ROOT/'runs'/('red-'+ref)/'raw')})
            assert r['exit']==1 and r['totals']['fail']==(7 if ref=='be9086e' else 3)
        r=run('red-text-110',['node','--test-reporter=tap','--test-timeout=15000',str(ROOT/'frozen/tests/imm-receipt-text-admission.test.js')],{'TSIMM_TEST_SCRIPT':str(old/'sources/7ffadc0.user.js')})
        assert r['exit']==1 and r['totals']['tests']==110
    elif mode=='green':
        r=run('green-evr',['node','--test-reporter=tap','--test-timeout=15000',str(old/'reconstructed-v2/witnesses.test.cjs')],{'TSIMM_TEST_SCRIPT':str(REPO/'TornScripture-Item-Market-Margin.user.js'),'EVR_OUTPUT':str(ROOT/'runs/green-evr/raw')});assert r['exit']==0 and r['totals']['tests']==9
        r=run('green-frozen-110',['node','--test-reporter=tap','--test-timeout=15000',str(ROOT/'frozen/tests/imm-receipt-text-admission.test.js')],{'TSIMM_TEST_SCRIPT':str(REPO/'TornScripture-Item-Market-Margin.user.js')});assert r['exit']==0 and r['totals']['tests']==110
    elif mode=='all':
        r=run('maintained-full',['node','--test','--test-reporter=tap','--test-timeout=15000',*[str(f.relative_to(REPO)) for f in sorted((REPO/'tests').glob('*.test.js'))]]);assert r['exit']==0
    elif mode=='individual':
        rows=[]
        for f in sorted((REPO/'tests').glob('*.test.js')):
            r=run('individual-'+f.name,['node','--test-reporter=tap','--test-timeout=15000',str(f.relative_to(REPO))]);assert r['exit']==0
            assert not any(r['totals'].get(k,0) for k in ['fail','cancelled','skipped','todo']);rows.append({'file':f.name,**r})
        (ROOT/'runs/individual-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
