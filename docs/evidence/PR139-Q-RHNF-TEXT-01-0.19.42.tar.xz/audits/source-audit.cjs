const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const run = promisify(execFile);
const crypto = require('node:crypto');
const acorn = require('../dependencies/node_modules/acorn');
const root = process.env.EVR_REPO || '/workspace/TornScripture';
const sha = x => crypto.createHash('sha256').update(x).digest('hex');
const file = 'TornScripture-Item-Market-Margin.user.js';
const protectedRows = [...fs.readFileSync(path.join(__dirname, '../authority/6334011162.md'), 'utf8')
  .matchAll(/\| `([^`]+)` \| `([a-f0-9]{64})` \|/g)].map(m => [m[1],m[2]]);
assert.equal(protectedRows.length, 21);
function inspect(source) {
  const declarations = new Map(), sites = { listeners:0, timeouts:0, intervals:0, observers:0, fetches:0, writers:0 };
  const counts = {};
  const ast = acorn.parse(source, { ecmaVersion:'latest', sourceType:'script' });
  function walk(node) {
    if (!node || typeof node !== 'object') return;
    if (node.type === 'FunctionDeclaration') {
      const n = node.id.name, key = n + '#' + (counts[n] = (counts[n] || 0) + 1);
      declarations.set(key, { name:n, start:node.start, end:node.end, full:source.slice(node.start,node.end), body:source.slice(node.body.start,node.body.end) });
    }
    if (node.type === 'CallExpression') {
      const n = node.callee?.name || node.callee?.property?.name;
      for (const [key,value] of Object.entries({listeners:'addEventListener',timeouts:'setTimeout',intervals:'setInterval',fetches:'fetch',writers:'writeCaptureTraders'})) if (n === value) sites[key]++;
    }
    if (node.type === 'NewExpression' && node.callee?.name === 'MutationObserver') sites.observers++;
    for (const v of Object.values(node)) if (Array.isArray(v)) v.forEach(walk); else if (v && typeof v === 'object') walk(v);
  } walk(ast);
  return { declarations, sites };
}
(async()=>{
 const refs = ['c95136b08ad8cc3f8cc4c4ac2ae7462cebaa2475','529400117f727da31a058b7941c29693f40bb1b3','6535ee86ee907951938118a201f247702ea1304e','602396de14a0edad7460d89720f9c8bd96fd61ef','cf18f5cad12ddbe015f5572f5868250bc1b4ea78','be9086ebede3bfe62208594af96e1eebd8f5f5d2','7f40d9e70b9e53682308e1487d044758dda19303','7ffadc0f0a41543e4d6cf2b3b613ea7721271041'];
 const report = { protected: {}, comparisons: {}, current: {} }; let base, baseInfo;
 for (const ref of refs) {
  const s=(await run('git',['show',ref+':'+file],{cwd:root,maxBuffer:8e6})).stdout, i=inspect(s);
  report.protected[ref]={};
  for(const [name,hash] of protectedRows){const d=i.declarations.get(name+'#1');assert.ok(d,name);assert.equal(sha(d.body),hash,ref+':'+name);report.protected[ref][name]={body:sha(d.body),declaration:sha(d.full),bytes:Buffer.byteLength(d.full)};}
  if(ref===refs.at(-1)){base=s;baseInfo=i;}
  const diff=(await run('git',['diff','--full-index',ref],{cwd:root,maxBuffer:16e6})).stdout;
  fs.writeFileSync(path.join(__dirname,'comparison-'+ref.slice(0,7)+'.patch'),diff);
  const hunks=diff.split('\n').filter(l=>l.startsWith('diff --git ')||l.startsWith('@@ '));report.comparisons[ref]={diffSha256:sha(diff),hunks};
 }
 const source=fs.readFileSync(path.join(root,file),'utf8'), info=inspect(source);
 for(const [name,hash]of protectedRows){const d=info.declarations.get(name+'#1');assert.equal(sha(d.body),hash,name);assert.equal(d.full,baseInfo.declarations.get(name+'#1').full,name+' full declaration');}
 const changes=[...info.declarations].filter(([k,d])=>baseInfo.declarations.get(k)?.full!==d.full).map(([key,d])=>({key,start:d.start,end:d.end,hash:sha(d.full)}));
 const removed=[...baseInfo.declarations.keys()].filter(k=>!info.declarations.has(k));assert.deepEqual(removed,[]);
 let rebuilt=base;
 for(const c of changes.slice().sort((a,b)=>baseInfo.declarations.get(b.key).start-baseInfo.declarations.get(a.key).start)){
  assert.ok(['prepareTraderCapturePriceItems#1','priceItemsFromParsedReceipt#1'].includes(c.key),c.key);
  const old=baseInfo.declarations.get(c.key);rebuilt=rebuilt.slice(0,old.start)+info.declarations.get(c.key).full+rebuilt.slice(old.end);
 }
 if(changes.length)rebuilt=rebuilt.replaceAll('0.19.41','0.19.42');
 assert.equal(source,rebuilt,'complete source reconstruction');assert.deepEqual(info.sites,baseInfo.sites);
 const literals=s=>[...new Set([...s.matchAll(/(['"`])(tornscripture-[a-z0-9-]+)\1/g)].map(m=>m[2]))].sort();assert.deepEqual(literals(source),literals(base));
 const metadata=s=>s.slice(0,s.indexOf('// ==/UserScript==')).replace(/0\.19\.4[12]/g,'VERSION');assert.equal(metadata(source),metadata(base));
 const reportFile='TornScripture-IMM-Trader-Report.user.js';
 const oldReport=(await run('git',['show',refs.at(-1)+':'+reportFile],{cwd:root,maxBuffer:4e6})).stdout;
 assert.equal(fs.readFileSync(path.join(root,reportFile),'utf8'),oldReport);
 report.current={sha256:sha(source),reportSha256:sha(oldReport),declarations:info.declarations.size,changes,removed,sites:info.sites,storageLiterals:literals(source),protectedCount:protectedRows.length,completeSourceReconstruction:true};
 const output=process.env.EVR_AUDIT_OUT || path.join(__dirname,'preflight-audit.json');fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report.current,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
