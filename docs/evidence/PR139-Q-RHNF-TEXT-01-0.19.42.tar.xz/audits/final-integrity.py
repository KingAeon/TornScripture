import pathlib,subprocess,json,hashlib,re,os
repo=pathlib.Path(os.environ.get('EVR_REPO','/workspace/TornScripture'))
root=pathlib.Path(__file__).resolve().parent.parent
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def sha(data):return hashlib.sha256(data).hexdigest()
old='7ffadc0f0a41543e4d6cf2b3b613ea7721271041'
assert git('rev-parse','HEAD').decode().strip()==old
assert git('rev-parse','HEAD^{tree}').decode().strip()=='c76450e1a723b74d617fbda74633ce3ccf038c68'
assert git('rev-list','--parents','-n','1','HEAD').decode().split()==[old,'7f40d9e70b9e53682308e1487d044758dda19303']
assert git('rev-parse','origin/main').decode().strip()=='529400117f727da31a058b7941c29693f40bb1b3'
assert git('rev-parse','--is-shallow-repository').strip()==b'false'
changed=git('diff','--cached','--name-only').decode().splitlines()
expected=['TornScripture-Item-Market-Margin.user.js','docs/BL-R01B-V22-IMPLEMENTATION.md','tests/imm-capture-n123.test.js','tests/imm-receipt-text-admission.test.js','tests/imm-receipt-text-controls.test.js']
assert changed==expected,changed
for f in git('ls-tree','-r','--name-only',old).decode().splitlines():
 if f in expected:continue
 assert (repo/f).read_bytes()==git('show',old+':'+f),f
version='tests/imm-capture-n123.test.js'
assert (repo/version).read_bytes()==git('show',old+':'+version).replace(b"'0.19.41'",b"'0.19.42'")
frozen=root/'frozen/tests/imm-receipt-text-admission.test.js'
assert sha(frozen.read_bytes())=='cba9a6645d36d6f785cf16e54876ea15648fefb95fd17b981ec4c0acc0e888c0'
assert frozen.read_bytes()==(repo/'tests/imm-receipt-text-admission.test.js').read_bytes()
js=[f for f in git('ls-files').decode().splitlines() if f.endswith(('.js','.cjs'))]
for f in js:subprocess.run(['node','--check',f],cwd=repo,check=True,capture_output=True)
for ref in [None,old,'529400117f727da31a058b7941c29693f40bb1b3','be9086ebede3bfe62208594af96e1eebd8f5f5d2']:
 subprocess.run(['git','diff','--check',*([ref] if ref else [])],cwd=repo,check=True,capture_output=True)
subprocess.run(['git','diff','--cached','--check'],cwd=repo,check=True,capture_output=True)
fsck=subprocess.run(['git','fsck','--full'],cwd=repo,capture_output=True,text=True);assert fsck.returncode==0
(root/'audits/fsck-final.txt').write_text(fsck.stdout+fsck.stderr)
for ref in [old,'529400117f727da31a058b7941c29693f40bb1b3','be9086ebede3bfe62208594af96e1eebd8f5f5d2']:
 (root/'audits'/('complete-diff-'+ref[:7]+'.patch')).write_bytes(git('diff','--binary','--full-index',ref))
diff=git('diff','--cached').decode()
secret_patterns=[r'gh[pousr]_[A-Za-z0-9]{20,}',r'github_pat_[A-Za-z0-9_]{20,}',r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',r'Bearer\s+[A-Za-z0-9_.-]{25,}']
assert not any(re.search(p,diff) for p in secret_patterns),'credential pattern in diff'
info=json.loads((root/'audits/final-source-audit.json').read_text())['current']
assert info['protectedCount']==21 and info['completeSourceReconstruction']
assert [c['key'] for c in info['changes']]==['prepareTraderCapturePriceItems#1','priceItemsFromParsedReceipt#1']
assert (root/'audits/financial-parser-before.json').read_bytes()==(root/'audits/financial-parser-after.json').read_bytes()
summary=json.loads((root/'runs/individual-summary.json').read_text());assert len(summary)==22
total=sum(r['totals'].get('pass',1) for r in summary);assert total==2065
assert all(r['exit']==0 and not any(r['totals'].get(k,0) for k in ['fail','cancelled','skipped','todo']) for r in summary)
full=json.loads((root/'runs/maintained-full/command.json').read_text());assert full['exit']==0 and full['totals']['pass']==2065
out={'head':old,'changedFiles':changed,'syntaxPass':len(js),'maintainedCases':total,'maintainedFiles':len(summary),'inventoryStandalonePass':True,'preservedFrozen110':sha(frozen.read_bytes()),'protectedBodies':21,'financialParserComparisons':19,'secretPatternScan':'PASS; synthetic/public-source review','sourceAudit':info,'stagedTreeBeforeEvidence':git('write-tree').decode().strip()}
(root/'audits/final-integrity.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='sourceAudit'},indent=2))
