const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = process.env.EVR_REPO || (fs.existsSync(path.join(__dirname, '../source')) ? path.join(__dirname, '../source') : '/workspace/TornScripture');
const { fixture, feedback, bookWrites, K, PENDING } = require(path.join(root, 'tests/helpers/imm-receipt-harness.cjs'));
const out = process.argv[2]; fs.mkdirSync(out, { recursive: true });
const huge = '1' + '0'.repeat(308), valid = 'Fixture Item x2 @ $1234 = $2468';
const snapshot = p => ({ storage: Object.fromEntries(p.memory), session: Object.fromEntries(p.session), input: p.input.value, draft: p.state.receiptAuditDraft, feedback: feedback(p), writes: p.writes });
(async () => {
  const cases = [
    ['recovered-overflow-valid-first', `${valid}\nOther Item x2 @ $${huge}`, false],
    ['recovered-overflow-invalid-first', `Other Item x2 @ $${huge}\n${valid}`, false],
    ['recovered-quantity-first', '2 x Fixture Item @ $1,234 = $2,468', true],
    ['finite-total-first', `Other Item x2 $${huge}\n${valid}`, true],
    ['finite-total-last', `${valid}\nOther Item x2 $${huge}`, true],
    ['compact-zero-quantity', `${valid}\nOther Itemx0 @ $NaN`, false],
    ['single-name-spaced-quantity', 'Widget x 2 @ $1234 = $2468', true],
  ];
  for (const [name, input, accepted] of cases) {
    const p = await fixture({ twoTraders: true }); p.input.value = input;
    const before = JSON.parse(JSON.stringify(snapshot(p)));
    await p.link(); await p.drain();
    const after = JSON.parse(JSON.stringify(snapshot(p)));
    fs.writeFileSync(path.join(out, name + '.json'), JSON.stringify({ before, after }, null, 2) + '\n');
    if (!accepted) {
      assert.equal(p.memory.get(K.book), before.storage[K.book]);
      assert.equal(p.memory.get(PENDING), before.storage[PENDING]);
      assert.equal(bookWrites(p).length, 0); assert.match(feedback(p).at(-1), /not captured: invalid price/i);
    } else { assert.equal(bookWrites(p).length, 1); assert.equal(p.memory.has(PENDING), false); }
    p.assertInput(input); p.assertAccounting();
  }
  console.log('Seven additional raw UI diagnostics PASS; overlapping assertions, excluded from acceptance tally');
})().catch(e => { console.error(e); process.exitCode = 1; });
