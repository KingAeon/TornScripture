const fs = require('node:fs');
const { runtime } = require('/workspace/TornScripture/tests/helpers/imm-capture-harness.cjs');
const huge = '1' + '0'.repeat(308);
const inputs = [
  'Fixture Item x2 @ $1234 = $2468',
  'Fixture Item × 2 @ $1,234 = $2,468',
  '2 x Fixture Item @ $1,234 = $2,468',
  '2xFixture Item @ $1234 = $2468',
  'Fixture Itemx2 @ $1234 = $2468',
  'Fixture Item x2 $2468',
  `Other Item x2 $${huge}`,
  `Other Item x2 @ $${huge}`,
  'Fixture Item x2 @ $1234.50 = $2469.00',
  'Fixture Item x1 @ $.50 = $.50',
  ...['Infinity', 'NaN', '1e400'].map(t => `Fixture Item x2 @ $1234 = $2468\nOther Item x0 @ $${t}`),
  '2 × Other Item @ missing',
  'Notes: saved $20 on this trade\nFixture Item x2 @ $1234 = $2468\nTotal: $2468',
  '{"items":[{"itemId":1,"itemName":"Fixture Item","quantity":2,"unitPrice":1e400}]}',
  '{"items":[{"itemId":1,"itemName":"Fixture Item","quantity":2,"unitPrice":"Infinity"}]}',
  '{"items":[{"itemId":1,"itemName":"Fixture Item","quantity":2,"totalValue":2468}]}',
  'https://www.torn.com/trade.php?ID=987654',
];
(async () => {
  const p = runtime(); await p.ready;
  const cases = inputs.map(input => ({ input, parsed: p.api.parseReceiptInput(input) }));
  fs.writeFileSync(process.argv[2], JSON.stringify(cases, (k, v) => typeof v === 'number' && !Number.isFinite(v) ? { nonfiniteNumber: String(v) } : v, 2) + '\n');
  console.log('Executed financial parseReceiptInput cases:', cases.length);
})().catch(e => { console.error(e); process.exitCode = 1; });
