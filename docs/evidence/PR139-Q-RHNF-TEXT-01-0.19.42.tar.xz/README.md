# PR #139 Q-RHNF-TEXT-01 — final author evidence, IMM draft 0.19.42

This archive records a fresh executable recovery and author verification. It is not independent Q/V1 acceptance, a browser/device test, or a release. The final Git commit and remote readback are recorded in the PR publication report because an archive cannot contain its own enclosing commit/checksum without a circular dependency.

## Provenance and immutable inputs

Starting branch: `agent/bl-r01b-v22-trader-refresh-implementation` in `KingAeon/TornScripture`. Starting HEAD `7ffadc0f0a41543e4d6cf2b3b613ea7721271041`, tree `c76450e1a723b74d617fbda74633ce3ccf038c68`, sole parent `7f40d9e70b9e53682308e1487d044758dda19303`; main/base `529400117f727da31a058b7941c29693f40bb1b3`. No original worktree survived on this executor. The owner's current fresh-execution instruction explicitly authorized archive recovery/reconstruction. A complete nonshallow native Git clone supplied all history and the 223 baseline blobs; their paths, modes and byte hashes matched the recursive remote tree.

The unmodified recovery archive is included as `PR139-RECOVERY-107-of-110.tar.xz`, SHA-256 `b256d43212a771967db9fcc62af30ed7d14d6bec29b6e1b767bd9205a1c79001`. All 183 inner entries verified before use. `recovery-original/` preserves its original execution evidence; recovery capture/working-tree data remain independently recoverable from the included container. The recovery archive proves the earlier 107/110 result only. No later 110/110 implementation bytes were found here or assumed.

The recovered 110 assertions are unchanged in both `frozen/tests/imm-receipt-text-admission.test.js` and `source/tests/imm-receipt-text-admission.test.js`, SHA-256 `cba9a6645d36d6f785cf16e54876ea15648fefb95fd17b981ec4c0acc0e888c0`. The original first and corrected pre-edit reconstructed bundles retain SHA-256 `1edb0c78b0adef051546d9f80a756eb14d1845352adedb7a0845f9f2b345e92e` and `cfc61dd8702559a140d63aabc8ae246997c83139648ab7e484f82dfea0f36e41`. Their manifests, hosts, mapping, original red logs and v1-to-v2 fixture correction are preserved. The permanently lost pre-EVR external V1 files were not recovered; these remain plainly labeled reconstructed assertions requiring independent semantic review.

`source/` contains the complete 225-file candidate checkout before addition of this archive and its checksum. `SOURCE.sha256.json` binds every file. `audits/final-integrity.json` records the corresponding pre-evidence tree. `authority/` contains current mandatory comments; `recovery-original/authority/` contains the earlier frozen contracts. Native Git/Node/runtime provenance is in `PROVENANCE.json`; no environment dump or credential files are included.

## Executed gates on the final source

- Unchanged starting full suite: 1,921/1,921 maintained cases, 20 files; 34 syntax checks; complete checkout parity and Git integrity; protected source audit before edits.
- Reconstructed historical red on exact `be9086e`: 9 cases, 2 positive controls pass, all seven rejection/history witnesses fail. On exact `7ffadc0`: 6 pass, exactly the three Q mixed-text witnesses fail. Each has nine complete raw before/after UI/store/write snapshots.
- Frozen 110 red on `7ffadc0`: 61 pass / 49 fail. Same unchanged assertions on the final source: 110/110 pass.
- Final V1-EVR-01 reconstructed suite: 9/9 pass, with new full raw snapshots. These cover the four old-V1 behavioral reconstructions, three Q witnesses and two positive controls; do not add overlapping reruns to acceptance totals.
- Full maintained command: 2,065/2,065 cases across all 22 files, original 15,000 ms timeout; zero failures/cancellations/skips/TODO. Every file also passes individually: 2,064 node:test cases plus the existing inventory assertion script. `runs/individual-summary.json` contains exact per-file commands/counts. The 219 existing RHNF cases, original 11 launcher and 10 integrated-launcher cases remain intact.
- New maintained controls: 34/34, including both row orders of finite total-only fallback, quantity-first and compact/spaced finite rows, additional malformed compact rows, denied/null locks, set/readback faults, retry and same/different-trader rearm. The earlier report's 26 controls were independently reconstructed here; eight further controls arose during bounded source review.
- Syntax: all 36 tracked JS/CJS files pass. `git fsck --full`, staged/working/comparison whitespace checks, complete diff review and unchanged-maintained-test audit pass.
- 21 protected full declarations/bodies match all eight historical pins and the final source. AST reconstruction permits only the two admission functions plus five coherent version sentinels. All other declarations, financial parsers, single writer, lock, HEV, Report and launcher code remain exact. Effect sites remain 35 listeners, 35 timeouts, 1 interval, 5 observers, 6 fetches and 4 existing writer calls; storage literals, permissions and public URLs remain unchanged.
- Nineteen actually executed financial receipt-parser outputs match the starting source, including nonfinite numeric distinctions. Seven additional raw UI diagnostics document the recovery's three failed controls and finite/compact controls; they overlap maintained assertions and are excluded from the tally.

Final IMM SHA-256 `a0f8cf10a9122a39ae4830fe414816dc49f7be3bbd0a19bac1ed4d44537c5607`; unchanged Report 0.2.3 SHA-256 `8f9884aad859476a16ae3106a3b5551de51938ede4e13c193b2be4d40923dd4b`.

## Reproduce without altering the preserved archive

First verify the external archive SHA-256 from the PR report/checksum file. Extract a separate working copy, then verify every entry in `MANIFEST.sha256` before running anything. Preserve the downloaded container. Tests use built-in Node 24.19.0, native `navigator.locks` and Web Crypto. No npm install is required; bundled Acorn 8.15.0 supports only the external source audit. No accounts, gameplay or network services are used by the test hosts.

From the extracted root in a disposable replay copy:

```bash
sha256sum -c MANIFEST.sha256
python3 run.py red
python3 run.py green
python3 run.py all
python3 run.py individual
```

`run.py` selects the packaged `source/` automatically and checks expected historical failure exits. It writes into `runs/` in the disposable replay copy; it never edits the frozen assertions. To test a separately cloned exact published commit instead, set `EVR_REPO` to that checkout. For direct transparent commands:

```bash
cd source
node --test --test-reporter=tap --test-timeout=15000 tests/*.test.js
cd ..
TSIMM_TEST_SCRIPT="$PWD/source/TornScripture-Item-Market-Margin.user.js" EVR_OUTPUT="$PWD/new-green-raw" node --test-reporter=tap --test-timeout=15000 recovery-original/reconstructed-v2/witnesses.test.cjs
```

The recorded exact historical commands and exit/timing receipts are under `runs/red-*`; final ones under `runs/green-*`, `runs/maintained-full` and `runs/individual-*`. Full original descriptions, assertion mapping and host limitations are in `recovery-original/reconstructed-v2/README.md`. Sources and dependency lock/license files are included.

## Diagnostics and limits

The initial tree-parity script mistakenly assumed GitHub's `git/trees/<commit>` response `sha` was the tree ID; that endpoint echoed the supplied commit ID. Re-querying the exact required tree ID and comparing all 223 entries resolved the audit assumption without source changes. The first financial-parser diagnostic selected the restricted test export rather than the existing module export (`TypeError: p.api.parseReceiptInput is not a function`); selecting the existing production module export resolved the diagnostic. These were host/audit errors, not failed product assertions or waived gates. The initial recovered 107/110 failing source/TAP remains immutable in the recovery container. Pre-review positive logs are retained locally separately; final decisions use the exact-source final logs in this archive.

All raw stores are synthetic sentinels. Receipt-link accounting checks allow only the frozen R8 counterparty name/ID/profile and Ledger timestamp update; quantities, FIFO, allocations, cash, cost/profit, audit/sale identities and seven adjacent stores remain exact. Pattern scan and source review found no credentials/private exports in the correction or evidence.

Independent Q must challenge replacement-fixture fidelity, hosts, historical sensitivity and the fixed product on the published exact HEAD. Full V1, owner desktop/TornPDA V2, provider carrier/lifecycle qualification, Ledger Integrity and explicit merge/release remain separate gates. Synthetic DOM/native Node locks do not prove browser hit testing, process kill/BFCache, userscript-manager timing or live account integrity. PR #139 must remain OPEN/DRAFT/UNMERGED and Issue #142 OPEN.

Before later authorized manual testing, export raw Trader Book, Ledger, pending/queue and Report backup bytes; run only the reviewed pair. No storage migration is introduced. Preserve newer authority on failure; do not normalize away evidence, restore stale backups or automatically install known-defective earlier candidates. A source rollback requires a separately reviewed forward revert and separate user-data reconciliation where needed.
