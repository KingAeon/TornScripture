# Q-RHNF-QUANTITY-03 author implementation evidence, draft0.19.44

Owner-authorized B only, starting exact2a5745773ba726127ce772d905666a223d1f1dc4/treec1ffeccb48f3c1e77314f0ea3bae1674525c4b71/parent4e5bab39b6e73b0d7c78aaa22e78c4ebe0f7e818. Main/base529400117f727da31a058b7941c29693f40bb1b3 remains untouched. Publication comment supplies resulting sole-parent HEAD/tree and enclosing archive checksum. No independent Q, V1/V2, merge/release/readiness, gameplay, account mutation or spending.

## Reproduction and authenticity

Verify MANIFEST.sha256 from this root. original-q.tar.xz is the unchanged independent Q archive:559908 bytes/SHA256e180a30fa45ed3304879422bfc1dc970b0705ec73cc0dfbd8e2fda5e81da62da/361 inner entries. Extract it into q/ to run source/hosts/reconstruction. The prior author archive was independently checked at d01f3e9b6c6d01503290f302997edf99dc9a1ad0772da2c2d29eb4c2b5fb2354/524 inner entries; all are recorded in author-manifest.log. It remains retrievable at the exact starting commit docs/evidence/PR139-Q-RHNF-ADMISSION-02-0.19.43.tar.xz, not redundantly nested here. Both archives' hashes/manifests were verified before product edits; original external source/assertions/hosts are unchanged. Lost pre-EVR originals remain lost; EVR is a disclosed reconstruction.

source/ contains every staged non-binary-archive file before this enclosing evidence pair is added, plus full Git blob/SHA256 source inventory. Existing earlier .tar.xz files are omitted only to avoid recursive evidence duplication; their checksums and immutable Git sources remain authoritative. Full nonshallow Git history is needed for maintained historical Report checks and audit refs. Clone the repository, select the published exact candidate, use Node24/native navigator.locks. No npm/account needed.

```
mkdir q
tar --no-same-owner -xJf original-q.tar.xz -C q
sha256sum -c MANIFEST.sha256
cd <complete-checkout>
node --test --test-reporter=tap --test-timeout=15000 tests/*.test.js
# from this extracted evidence root, supply explicit source/output paths:
TSIMM_TEST_SCRIPT=<candidate>/TornScripture-Item-Market-Margin.user.js Q_RAW=<new-output> node --test-reporter=tap --test-timeout=15000 --test-name-pattern='reject quantity-(semicolon|colon|parens)' q/fresh/admission.test.cjs
```

Original scripts record actual workspace paths; adjust explicitly for portable replay. audit.cjs expects sibling TornScripture plus extracted q/ and author/; alternatively materialize those directories from original immutable archives. run-regressions.py records full subprocess arguments/env/exits; historical source baseline.user.js is byte-equal to exact starting Git blob. PRE-EDIT-FROZEN* and FROZEN-FINAL preserve assertion/host hashes. Raw UI test snapshots include before/after, entire book/Ledger/neighbors, pending arm, input, write traces and feedback. All data is synthetic test data, not a real account export.

## Executed results

Baseline maintained2255/2255. Original six unchanged Q witnesses RED0/6 then finalGREEN6/6. Final maintained2475/2475,25 files,original15000ms timeout. New additive220/220, corrected fixture historical RED148PASS/72FAIL. External original receipt89/89; history/provider/Report/launcher25/25; frozen110/110; reconstructedEVR9/9. Source audit protected21 across10 historical refs, financial19, syntax39, version5matching sentinels, effects unchanged35listeners/35timeouts/1interval/5observers/6fetches/4sharedwriter call sites. No storage/schema/permissions/URL/parser/Report/provider/HEV/launcher/coordinator/writer change.

The original fresh62 negative/positive file is preserved and runs at56PASS/6FAIL. Those six amount-closing bracket/exclamation negative assertions are deliberately NOT newly frozen defects; behavior and policy are unchanged. Their raw observations are retained. The correctly selected required subset passes56/56, using test-name-pattern '^(?:reject (?!junk-(?:closing-unit|closing-total|bang-total))|positive )'. Selection command diagnostics that accidentally selected62 or52 are retained and not counted as new acceptance runs. No assertions were deleted, renamed, or relaxed.

Diagnostic history: additive v1 seeded only Other Item, incorrectly making the legitimate Receipt: Other Item positive control match a partial catalog name. v2 added full names but used a malformed normalizedName for the colon. The final setup uses the existing normalization format and unchanged assertions; final baseline RED is replayed transparently, not falsely called pre-edit frozen. Initial v1/v2 sources, raw and TAP remain. First local product implementation overclassified prose via a nonnumeric prefix fallback and failed5 maintained cases/3 overlapping frozen cases. Removing that fallback within the same full-lexeme boundary restored the explicitly frozen benign prose semantics; first product source and all failed logs retained. No financial parser or external assertion change accommodated it. Final required runs are green. These are author implementation checks, not independent Q.

## Scope, review, manual gate and recovery

Only prepareTraderCapturePriceItems behavior changes, plus five0.19.44 sentinels, exact bootstrap equality,220 additive assertions and implementation docs/evidence. Full staged cumulative/amendment diffs, source AST/callers/effects/protected/parity and financial audits are included. Existing per-file bodies outside the one function reconstruct byte-identically from starting HEAD after version substitution; no unrelated source change. Final GitHub tree/commit/blob and archive re-download checks occur after this archive is created and are recorded separately in the final PR report.

After separately authorized fresh independent Q, then V1, owner desktop/TornPDA V2 must preserve raw Book/Ledger/pending/queue/Report backups, test both-order suffix rejection and exact-state preservation, finite/grouped/total-only capture once, correction/retry/lock/failure recovery, provider/Report/launcher and Ledger Integrity. Synthetic UI/native Node locks do not establish layout/touch/clipboard, userscript timing, provider carrier/markup, lifecycle/process kill/BFCache or live account integrity.

Keep newer authority, pause captures if a discrepancy occurs; no schema migration/reset or stale-backup restore is authorized. Rollback requires a reviewed forward revert and separate data reconciliation; historical defective builds are for reproducibility only. Stop after publication, PR139 OPEN/DRAFT/UNMERGED and Issue142 OPEN. Any later gate requires distinct owner authorization.
