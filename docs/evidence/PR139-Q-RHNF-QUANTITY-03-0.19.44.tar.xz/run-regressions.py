import os,subprocess,pathlib,json
E=pathlib.Path(__file__).resolve().parent;R=E.parent/'TornScripture';Q=E/'q';F=R/'TornScripture-Item-Market-Margin.user.js'; receipts=[]
def run(n,args,cwd,env={}):
 p=subprocess.run(args,cwd=cwd,env=dict(os.environ,TSIMM_TEST_SCRIPT=str(F),**env),stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (E/(n+'.tap')).write_bytes(p.stdout);receipts.append(dict(name=n,args=args,cwd=str(cwd),env=env,exit=p.returncode));print(n,p.returncode,p.stdout.decode().splitlines()[-9:])
for n,f,env in [('external89','original/fresh/adversarial.test.cjs',{'Q_RAW':str(E/'external-green-raw')}),('surfaces25','original/fresh/surfaces-v4.test.cjs',{'Q_REPO':str(R),'Q_RAW':str(E/'surfaces-green-raw')}),('frozen110','original/author-unpacked/frozen/tests/imm-receipt-text-admission.test.js',{}),('EVR9','original/author-unpacked/recovery-original/reconstructed-v2/witnesses.test.cjs',{'EVR_OUTPUT':str(E/'EVR-green-raw')}),('fresh-full62','fresh/admission.test.cjs',{'Q_RAW':str(E/'fresh-full-green-raw')})]:
 run(n,['node','--test-reporter=tap','--test-timeout=15000',f],Q,env)
run('fresh-required56',['node','--test-reporter=tap','--test-timeout=15000','--test-name-pattern=^(?!reject junk-(closing-unit|closing-total|bang-total)).*','fresh/admission.test.cjs'],Q,{'Q_RAW':str(E/'fresh-required-raw')})
(E/'regression-commands.json').write_text(json.dumps(receipts,indent=2))
