# Q-RHNF-ADMISSION-02 author implementation evidence

This archive records the owner-approved implementation on existing draft PR #139. It is author verification, not a fresh independent Q verdict, full V1 or desktop/TornPDA V2 acceptance. No merge, release, installation, account action or infrastructure spending occurred. The containing commit's sole parent must be 4e5bab39b6e73b0d7c78aaa22e78c4ebe0f7e818; released main/base remains 529400117f727da31a058b7941c29693f40bb1b3. The publication comment identifies final HEAD/tree and this archive's external SHA-256.

## Contents and verification

- `source/`: complete staged non-enclosing-archive source snapshot, including the prior immutable author archive. Final publication additionally contains this enclosing archive and its checksum; those two self-referential paths are necessarily absent here.
- `original-independent-q.tar.xz`: immutable original reviewer archive, 1,375,896 bytes; SHA-256 f136732d843af1c0ab91978826ee6b9ce5a50f736acf6ebc89b931aa0f944190. Its original raw witnesses, hosts and assertions remain unchanged. Extract into `evidence/q-original/` to replay.
- `evidence/`: frozen specification/authorization/provenance, pre-edit hashes, baseline and original red TAP, final green TAP, original before/after/repeat stores and traces, additive raw snapshots, individual-file command receipts, source audits and complete isolated/cumulative non-enclosing-evidence diffs.
- `MANIFEST.sha256`: every regular file beneath this root, excluding itself. Verify all entries after extraction.

Before editing, native full-history clone, exact pins, original baseline 2065/2065, 227 source blobs, 36 syntax paths, eight historical protected references and original independent archive/623-entry manifest were verified. Original 89 assertions replayed at 67 PASS/22 FAIL. Additive file 1 was frozen before product edits (43 PASS/123 FAIL); punctuation cases were frozen separately before their corresponding correction (0 PASS/24 FAIL). Frozen hashes and original failure logs remain available.

Final maintained result is 2255/2255 across 24 files (2065 existing +190 additive); every file also passed separately (2254 node:test assertions plus standalone inventory success). Original external receipt 89/89, broader surfaces 25/25, overlapping minimal 3/3, frozen 110/110, reconstructed EVR 9/9. There are no skipped/cancelled/TODO cases. Do not add overlapping reruns into an inflated total. `VALIDATION.json` and `individual/commands.json` identify actual commands, exits and TAP summaries.

Only prepareTraderCapturePriceItems changes behavior, plus five coherent version sentinels to draft 0.19.43. The sole existing test edit is the corresponding exact version expectation; behavioral assertions and both hosts remain unchanged. Two additive files contain 190 cases. 21 protected complete functions match eight historical references plus starting candidate; 19 actual financial parser outputs match with nonfinite values distinguished; Report 0.2.3 and source effects/storage metadata remain unchanged. See `final-audit.json` and the implementation guide for exact compatibility decisions. In particular, finite prefix-less fields retain the existing parser's interpretation; this correction does not introduce universal equation reconciliation. Name-first header rows unsupported by that financial grammar reject price capture; supported quantity-first forms still pass.

The final audit was corrected only for host setup: v1 mistakenly used the narrow capture test API without a financial parser export; v2 used strings instead of the frozen `{nonfiniteNumber: ...}` serialization. V3/final uses the actual production module export, matching empty-catalog state and original nonfinite representation. Both initial failed scripts/logs are preserved. No product or frozen assertions changed to accommodate these audit errors. The initial additive header tests also revealed that a broad punctuation exclusion would be unsafe; its 24 red cases were frozen, then the single admission boundary was corrected and all final cases passed.

## Portable replay

Use a complete native Git checkout of the containing publication commit with Node 24 and native navigator.locks. No npm installation or player account is needed. Keep evidence output outside the checkout. From the extracted archive root:

```bash
mkdir -p evidence/q-original
tar -xJf original-independent-q.tar.xz -C evidence/q-original
sha256sum -c MANIFEST.sha256
export ADMISSION_REPO=/absolute/path/to/full/checkout
export TSIMM_TEST_SCRIPT="$ADMISSION_REPO/TornScripture-Item-Market-Margin.user.js"
node evidence/final-audit.cjs
cd "$ADMISSION_REPO"
node --test --test-reporter=tap --test-timeout=15000 tests/*.test.js
```

From `evidence/q-original`, set Q_RAW to a new absolute output directory and run `node --test-reporter=tap --test-timeout=15000 fresh/adversarial.test.cjs`. Run the preserved surfaces file with Q_REPO pointing to that complete checkout; run the frozen 110 and EVR witness files with the same TSIMM_TEST_SCRIPT and a fresh EVR_OUTPUT. Original README/REVIEW-NOTES document host limits and historical red replay. Never relabel reconstructed EVR fixtures as the permanently lost pre-EVR original external sources.

Publication uses verified GitHub write permission, exact staged Git blob/tree parity, one sole-parent commit and an expected-old-head non-force update of the existing PR branch because native Git push has no credentials. Remote commit/tree/blob parity, independently downloaded enclosing archive and all manifest hashes are checked after publication and recorded in the final PR comment. This archive cannot attest to its own future remote readback.

## Remaining gates and recovery

Stop after author publication. Fresh separately owner-authorized independent Q must challenge the exact new HEAD before full V1, owner desktop/TornPDA V2 with raw Trader Book/Ledger/pending/queue/Report backups, Ledger Integrity and separate merge/release disposition. Synthetic DOM/storage/clocks and native Node locks do not establish device layout, touch, clipboard, real markup, userscript timing, process kill/BFCache or account integrity.

For later authorized device checks, arm a controlled trader, attempt both-order malformed explicit fields and header collisions, verify zero price writes and exact arm/input/count/clock/proof retention, then correct and save once. Check native contention/retry, provider round trip, Report refusal over newer proof and launcher behavior before Ledger Integrity. Preserve newer raw evidence. No storage migration/reset or stale-backup restore is authorized. Keep defective old candidates for reproducibility only; rollback requires a separately reviewed forward revert and separately assessed data reconciliation. PR #139 remains OPEN/DRAFT/UNMERGED and Issue #142 remains OPEN.
