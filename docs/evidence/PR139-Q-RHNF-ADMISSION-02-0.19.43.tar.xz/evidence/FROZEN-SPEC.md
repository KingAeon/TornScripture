# [S][FROZEN][OWNER-APPROVED] Q-RHNF-ADMISSION-02: Complete explicit-field and header-collision receipt admission

**Owner decision:** “Agreed. [S] is authorized.” This freezes **specification only** after fresh independent [Q] BLOCKED on draft IMM 0.19.42. **No [B] coding, tracked tests, commit, [Q] rerun, [V1]/[V2], merge, release, ready transition, user/account mutation or infrastructure spending is authorized by this specification.** Owner must separately approve execution.

## Provenance and binding evidence

- Repo `KingAeon/TornScripture`; existing PR **#139 OPEN/DRAFT/UNMERGED**, branch `agent/bl-r01b-v22-trader-refresh-implementation`; issue #142 remains OPEN.
- Frozen candidate **HEAD `4e5bab39b6e73b0d7c78aaa22e78c4ebe0f7e818`**, recursive tree **`8b42c64e2a36e353b4d05d81dbf6e480d987514d`**, sole parent **`7ffadc0f0a41543e4d6cf2b3b613ea7721271041`**; released main/base `529400117f727da31a058b7941c29693f40bb1b3`. IMM draft 0.19.42; Trader Report 0.2.3 unchanged.
- **Fresh independent [Q] BLOCKED primary report:** https://github.com/KingAeon/TornScripture/pull/139#issuecomment-6377970757
- **Durable 31-part independently verified evidence index:** https://github.com/KingAeon/TornScripture/pull/139#issuecomment-6377951952 . Archive `PR139-Independent-Q-20261024-durable.tar.xz`, SHA-256 `f136732d843af1c0ab91978826ee6b9ce5a50f736acf6ebc89b931aa0f944190`; 714 members, 623 manifest entries.
- Binding earlier contracts: frozen V1-EVR-01 https://github.com/KingAeon/TornScripture/pull/139#issuecomment-6337210331 ; RHNF Tier 3 behavior https://github.com/KingAeon/TornScripture/pull/139#issuecomment-6331694165 ; prior author implementation https://github.com/KingAeon/TornScripture/pull/139#issuecomment-6358433445 ; original prior Q BLOCKED https://github.com/KingAeon/TornScripture/pull/139#issuecomment-6335343555 ; original v2.2, R1–R8, HEV, provider/Report and GG-UI integration freezes. Repository AGENTS.md, Divine Knowledge INDEX→NOW→AUTHORITY/relevant domains, Charter, Operating Rules, Development Workflow, Ledger Invariants continue binding. Canonical live GitHub evidence supersedes stale memory.
- Independent review actually ran maintained **2065/2065 PASS** on 22 files, original frozen **110/110**, EVR reconstructed **9/9**, new **92/114 PASS, 22 FAIL** (18 malformed explicit-field + 4 item-shaped header collisions), tracked syntax **36/36**, protected bodies **21/21**, financial parser comparisons **19/19**. This is a product Q BLOCKED, not an environment blocker.

## One bounded Tier 3 admission-boundary correction

**Repair admission of complete raw receipt evidence before lossy filtering and before the financial audit parser's fallback can manufacture a finite success.** This is one coherent correction, **not** a blacklist for `Infinity` alone, nor a rewrite of the financial parser. The target is specifically `prepareTraderCapturePriceItems` / `priceItemsFromParsedReceipt` and their tightly necessary helpers and additive tests. Inspect full callers, storage writes, and original raw evidence first. Existing single shared `writeCaptureTraders` sink, native exclusive capture transition, replay proof, arm semantics and Report adapter stay architecturally untouched.

### A. Explicit token/field integrity, prefix-independent

For **recognizable item rows** and **present explicit fields**:
1. Treat the full lexical `@` unit-price field and `=` total field as evidence **whether or not a dollar sign appears**. Do not re-interpret a malformed *present* field as an absent optional field or total-only fallback. Do not allow the valid surviving dollar token to camouflage a malformed second field.
2. Reject entire receipt price capture on unsupported/malformed explicit numeric token, nonfinite/overflow exponent, negative/zero where disallowed, unsupported text such as `unavailable`, malformed separators/currency or embedded trailing junk, and malformed/nonpositive/overflowing quantity. Validate raw token boundaries and full consumption, avoiding permissive partial numeric parsing or accidental fallback.
3. Verify consistency of explicit unit, quantity and total where existing approved finite semantics require it. Do **not** invent a new rounding/decimal/discount/currency policy; preserve current legitimately supported variants and financial audit behavior. Any ambiguity about valid historical supported precision/totals must be documented and escalated instead of rejecting established valid receipts.
4. Positive legacy quantity-first, compact/spaced/unicode formatting, finite decimal, supported genuine **missing-unit total-only fallback** in both orders, harmless headings/totals/currency prose, and case/spacing variants continue to work. The *presence* of `@` with invalid unit disables that fallback; a malformed `=` cannot be silently dropped and cause the unit to be treated as total.

### B. Header/item collision safety

Before excluding a line as a harmless heading, decide whether it is **recognizable item-shaped evidence** with a quantity and explicit price fields. Item-shaped rows beginning with `Cash Item` or `Receipt:`, especially `Cash Item x0 @ $Infinity` and `Receipt: Other Item x0 @ $Infinity`, must not disappear behind prefix/header heuristics. If malformed, reject whole receipt capture. If fully valid and supported, retain it as item evidence rather than discarding it solely due to the heading prefix. Genuine prose headings, financial summaries, benign currency prose and non-item text remain ignored as previously permitted. Do not start admitting arbitrary unknown lines as prices.

### C. Atomic failure state and proof

For any invalid recognizable raw item or malformed *present* explicit field alongside any otherwise valid item:
- **0 Trader Book price writes**; original quote 500 (test fixture), check/capture count 7, prior success timestamp, raw canonical/legacy historical items including unknown/nested fields, all completion markers/outcome and raw audit stores preserved under previously frozen invariants.
- Strong arm retained byte-for-byte; receipt textarea retained; truthful invalid-evidence feedback; no false `captured`, no `parsedCount` marker or successful financial quote. Respect solely frozen intentional R8 counterparty-link/timestamp exception, and do not use it to excuse a price/book mutation.
- Ordering of valid/invalid lines, repeated clicks, native lock contention, retry/rearm, read/write failure, provider import and cleanup must not change fail-closed behavior. Exact-once successful finite capture remains valid.

## Required red-first evidence and additive tests

Before product edits on approved future [B], independently materialize complete executable nonshallow repo/Node native Locks checkout with clean tree, verify head/tree/parent/base, complete diff, test baseline, existing archive retrieval/checksums and 21 protected bodies. Rehydrate **unaltered fresh independent Q adversarial assertions and original raw witnesses** from the immutable Q archive and freeze all source/host/fixture hashes before any correction. Show all **22 actual product failures red on exact 4e5bab3** in initialized production UI. Preserve raw before/after, book-write trace, arm/count/timestamp/completion, text/feedback, line order, lock context and TAP exit codes. Do not weaken, rename, or silently bypass Q assertions or pretend author-created substitutions are original external fixtures.

Add tightly scoped maintained regression cases for:
- no-dollar malformed `@ Infinity`, `@ NaN`, `@ 1e400`, `@ -1`, `@ unavailable` and related unsupported/malformed token boundaries, plus malformed explicit `= Infinity`, `= NaN`, `= 1e400`, `= -2468`; **both item orders** and partial-surviving-token traps, fully initialized actual save click;
- four `Cash Item`/`Receipt:` item-shaped header collisions, plus benign headings and genuine finite `Cash Item`/`Receipt:` item controls, if supported by existing grammar;
- malformed quantity, mixed valid/invalid rows, token spacing/prefix/overflow boundaries and cases that look valid only after line filtering;
- matching supported finite receipts, legitimate missing-unit total-only cases both orders, quantity-first, compact/spaced/unicode, benign prose, genuine financial parser compatibility and all original zero-price/no-price historical invariants;
- 22 independently disclosed counterexamples + fresh self-challenging edge cases, not only a narrow fixture-targeted PASS.

After correction, the **same original 22 frozen external cases** and frozen 110, EVR reconstructed 9, all maintained suites must be green. If any fails or host cannot replay, STOP with factual BLOCKED and full evidence. New target draft IMM metadata is **0.19.43 only if actual product source changes**; keep Trader Report 0.2.3 unchanged and released main untouched. Review 21 protected bodies across eight frozen references; 19 financial parser outputs; provider/Report/HEV/replay/recovery/GG launcher and seven neighbor-store equivalence; full source effects, metadata/URL/storage, syntax, Git integrity, nontruncated full diffs, secret scan and financial integrity. Existing 2065 maintained tests must remain unchanged/unweakened; additive assertions allowed.

Produce independently retrievable sanitized source/host/fixture/log/raw-state archive with SHA-256+manifest and verifiable download/retrieval. Full final author-side PASS is necessary but **not independent Q acceptance**.

## Hard boundaries and subsequent gates

No new store/schema/migration, lock/writer/endpoint, autonomous gameplay, listener/timer/observer/fetch, general parser rewrite, protected accounting/lot/FIFO/cash/profit/receipt audit alteration, Report modification, UI change, main push, new PR, unrelated cleanup or test-assertion weakening. No infrastructure purchase. If existing grammar and header ambiguity cannot be resolved without an unapproved behavior choice, **STOP and return a concrete scoped decision request** instead of inventing policy.

**This [S] freezes the correction but DOES NOT AUTHORIZE CODING.** Owner's subsequent distinct `[B]` permission is required to implement on the existing draft PR branch; only a fresh separately approved **[Q]** after author publication may determine independent acceptance. Then full [V1], owner desktop/TornPDA [V2]/Ledger Integrity with raw backups, and distinct merge/release approval. Keep #139 OPEN/DRAFT/UNMERGED and #142 OPEN until explicit later owner disposition.
