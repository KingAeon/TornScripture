const fs = require('node:fs'), path = require('node:path'), cp = require('node:child_process');
const assert = require('node:assert/strict'), crypto = require('node:crypto');
const E = __dirname, Q = path.join(E, 'q-original');
const R = process.env.ADMISSION_REPO || path.join(E, '..', 'TornScripture');
const acorn = require(path.join(Q, 'author-unpacked/dependencies/node_modules/acorn'));
const FILE = 'TornScripture-Item-Market-Margin.user.js';
const BASE = '4e5bab39b6e73b0d7c78aaa22e78c4ebe0f7e818';
const MAIN = '529400117f727da31a058b7941c29693f40bb1b3';
const git = (...args) => cp.execFileSync('git', args, { cwd: R, maxBuffer: 32e6 });
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
function parse(source) {
  const functions = new Map(), effects = {};
  function walk(n) {
    if (!n || typeof n !== 'object') return;
    if (n.type === 'FunctionDeclaration') functions.set(n.id.name, {
      start: n.start, end: n.end, full: source.slice(n.start, n.end), body: source.slice(n.body.start, n.body.end) });
    if (n.type === 'CallExpression' || n.type === 'NewExpression') {
      const name = n.callee?.name || n.callee?.property?.name;
      if (['addEventListener', 'setTimeout', 'setInterval', 'MutationObserver', 'fetch', 'writeCaptureTraders'].includes(name))
        effects[name] = (effects[name] || 0) + 1;
    }
    for (const v of Object.values(n)) if (Array.isArray(v)) v.forEach(walk); else if (v && typeof v === 'object') walk(v);
  }
  walk(acorn.parse(source, { ecmaVersion: 'latest' })); return { functions, effects };
}
const before = git('show', BASE + ':' + FILE).toString(), current = fs.readFileSync(path.join(R, FILE), 'utf8');
const a = parse(before), b = parse(current);
const changed = [...b.functions].filter(([k, v]) => a.functions.get(k)?.full !== v.full).map(([k]) => k);
assert.deepEqual(changed, ['prepareTraderCapturePriceItems']);
assert.deepEqual([...a.functions.keys()], [...b.functions.keys()]);
const f = a.functions.get(changed[0]);
assert.equal((before.slice(0, f.start) + b.functions.get(changed[0]).full + before.slice(f.end))
  .replaceAll('0.19.42', '0.19.43'), current);
assert.deepEqual(a.effects, b.effects);
const literals = s => [...new Set([...s.matchAll(/(['"`])(tornscripture-[a-z0-9-]+)\1/g)].map(m => m[2]))].sort();
assert.deepEqual(literals(before), literals(current));
assert.equal(before.slice(0, before.indexOf('// ==/UserScript==')).replace('0.19.42', '0.19.43'),
  current.slice(0, current.indexOf('// ==/UserScript==')));
const protectedRows = [...fs.readFileSync(path.join(Q, 'comment-6334011162.md'), 'utf8')
  .matchAll(/\| `([^`]+)` \| `([a-f0-9]{64})` \|/g)].map(m => [m[1], m[2]]);
assert.equal(protectedRows.length, 21);
const refs = ['c95136b08ad8cc3f8cc4c4ac2ae7462cebaa2475', MAIN,
  '6535ee86ee907951938118a201f247702ea1304e', '602396de14a0edad7460d89720f9c8bd96fd61ef',
  'cf18f5cad12ddbe015f5572f5868250bc1b4ea78', 'be9086ebede3bfe62208594af96e1eebd8f5f5d2',
  '7f40d9e70b9e53682308e1487d044758dda19303', '7ffadc0f0a41543e4d6cf2b3b613ea7721271041', BASE];
const protectedAudit = {};
for (const ref of refs) {
  const old = parse(git('show', ref + ':' + FILE).toString()); protectedAudit[ref] = {};
  for (const [name, expected] of protectedRows) {
    assert.equal(hash(old.functions.get(name).body), expected);
    assert.equal(old.functions.get(name).full, b.functions.get(name).full);
    protectedAudit[ref][name] = hash(b.functions.get(name).full);
  }
}
const frozen = JSON.parse(fs.readFileSync(path.join(E, 'PRE-EDIT-FROZEN.json')));
const frozenHeader = JSON.parse(fs.readFileSync(path.join(E, 'PRE-HEADER-FROZEN.json')));
for (const [name, expected] of Object.entries({ ...frozen, ...frozenHeader })) {
  if (name !== FILE) assert.equal(hash(fs.readFileSync(path.join(R, name))), expected);
  else assert.equal(hash(before), expected);
}
const oldTests = git('ls-tree', '-r', '--name-only', BASE, 'tests').toString().trim().split('\n');
const testChanges = [];
for (const name of oldTests) {
  const old = git('show', BASE + ':' + name), next = fs.readFileSync(path.join(R, name));
  if (!old.equals(next)) {
    assert.equal(name, 'tests/imm-capture-n123.test.js');
    assert.equal(old.toString().replaceAll('0.19.42', '0.19.43'), next.toString());
    testChanges.push({ name, change: 'exact version sentinel only' });
  }
}
for (const line of fs.readFileSync(path.join(Q, 'MANIFEST.sha256'), 'utf8').trim().split('\n')) {
  const [h, name] = line.split('  '); assert.equal(hash(fs.readFileSync(path.join(Q, name))), h);
}
const reportFile = 'TornScripture-IMM-Trader-Report.user.js';
assert.equal(hash(fs.readFileSync(path.join(R, reportFile))), '8f9884aad859476a16ae3106a3b5551de51938ede4e13c193b2be4d40923dd4b');
const syntaxFiles = [...new Set([...git('ls-files', '*.js', '*.cjs').toString().trim().split('\n'),
  'tests/imm-receipt-explicit-fields.test.js', 'tests/imm-receipt-header-boundaries.test.js'])];
for (const name of syntaxFiles) cp.execFileSync('node', ['--check', name], { cwd: R });
const { runtime } = require(path.join(R, 'tests/helpers/imm-capture-harness.cjs'));
const p = runtime();
const expectedFinancial = JSON.parse(fs.readFileSync(path.join(Q, 'financial-before.json')));
assert.equal(expectedFinancial.length, 19);
const clean = value => JSON.parse(JSON.stringify(value, (_, v) => typeof v === 'number' && !Number.isFinite(v) ? String(v) : v));
const actualFinancial = expectedFinancial.map(({ input }) => ({ input, parsed: clean(p.api.parseReceiptInput(input)) }));
assert.deepEqual(actualFinancial, expectedFinancial);
fs.writeFileSync(path.join(E, 'final-financial.json'), JSON.stringify(actualFinancial, null, 2) + '\n');
const secret = /(?:-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,}|AKIA[A-Z0-9]{16}|sk-proj-[A-Za-z0-9_-]{40,})/;
for (const name of [FILE, ...syntaxFiles.filter(n => n.startsWith('tests/imm-receipt-'))])
  assert.equal(secret.test(fs.readFileSync(path.join(R, name), 'utf8')), false, name);
git('diff', '--check'); git('diff', '--cached', '--check');
const fsck = git('fsck', '--full').toString();
fs.writeFileSync(path.join(E, 'final-amendment.patch'), git('diff', '--full-index', BASE));
fs.writeFileSync(path.join(E, 'final-cumulative.patch'), git('diff', '--full-index', MAIN));
const result = { changedFunctions: changed, effects: b.effects, storageLiterals: literals(current),
  protectedReferences: protectedAudit, protectedCount: 21, syntaxFiles, financialComparisons: 19, testChanges,
  sourceSha256: hash(current), fsck, reportUnchanged: true, originalArchiveManifestEntries: 623 };
fs.writeFileSync(path.join(E, 'final-audit.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ changedFunctions: changed, protectedCount: 21, protectedRefs: refs.length,
  syntax: syntaxFiles.length, financial: 19, effects: b.effects, testChanges, sourceSha256: hash(current) }));
